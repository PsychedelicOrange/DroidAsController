package redlaboratory.jvjoyinterface;

public class FFBEType {

}
