package redlaboratory.jvjoyinterface;

public class FfbGenCB {

}
