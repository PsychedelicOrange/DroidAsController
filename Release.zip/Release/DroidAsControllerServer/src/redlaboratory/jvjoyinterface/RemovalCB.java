package redlaboratory.jvjoyinterface;

public interface RemovalCB {
	
	void changedCB(boolean removed, boolean first, Object userData);
	
}
